// app/export.tsx
import React, { useState, useEffect } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, ActivityIndicator, Alert, Share, Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import * as FileSystem from 'expo-file-system';
import * as Sharing from 'expo-sharing';
import { WebView } from 'react-native-webview';
import { theme } from '../lib/theme';
import { useStore } from '../lib/store';
import {
  parseManuscript, generateHTML, generateEPUBContent, STYLES,
} from '../lib/formatter';

type ExportFormat = 'pdf' | 'epub' | 'docx';
type ExportStatus = 'idle' | 'generating' | 'done' | 'error';

const STEPS = [
  'Parsing manuscript structure...',
  'Detecting chapters and sections...',
  'Applying typography and styles...',
  'Building table of contents...',
  'Generating PDF layout...',
  'Encoding EPUB structure...',
  'Building DOCX document...',
  'Finalizing all formats...',
];

export default function ExportScreen() {
  const router = useRouter();
  const store = useStore();
  const {
    title, author, subtitle, blurb, manuscript, selectedStyle,
    fontSize, pageSize, includeToc, includeCopyright, includePageNumbers, includeCover,
    isPro, exportCount, incrementExportCount,
  } = store;

  const [status, setStatus] = useState<ExportStatus>('idle');
  const [stepIndex, setStepIndex] = useState(0);
  const [progress, setProgress] = useState(0);
  const [generatedPaths, setGeneratedPaths] = useState<Record<string, string>>({});
  const [showPreview, setShowPreview] = useState(false);
  const [selectedFormats, setSelectedFormats] = useState<Set<ExportFormat>>(new Set(['pdf', 'epub', 'docx']));

  const safeName = (title || 'ebook').toLowerCase().replace(/[^a-z0-9]/g, '-').replace(/-+/g, '-');

  const toggleFormat = (fmt: ExportFormat) => {
    const next = new Set(selectedFormats);
    if (next.has(fmt)) { if (next.size > 1) next.delete(fmt); }
    else next.add(fmt);
    setSelectedFormats(next);
  };

  const meta = { title, author, subtitle, blurb };
  const blocks = parseManuscript(manuscript);
  const htmlContent = generateHTML(meta, blocks, selectedStyle, {
    includeToc, includeCopyright, includePageNumbers, includeCover, fontSize,
  });

  const canExport = !(!isPro && exportCount >= 3);

  const startExport = async () => {
    if (!canExport) {
      router.push('/paywall');
      return;
    }
    if (selectedFormats.size === 0) { Alert.alert('Select a format', 'Please choose at least one export format.'); return; }

    setStatus('generating');
    setProgress(0);
    const paths: Record<string, string> = {};

    for (let i = 0; i < STEPS.length; i++) {
      setStepIndex(i);
      setProgress((i + 1) / STEPS.length);
      await sleep(350 + Math.random() * 200);
    }

    try {
      // Write HTML file (renders as PDF via WebView print)
      if (selectedFormats.has('pdf')) {
        const htmlPath = FileSystem.documentDirectory + `${safeName}.html`;
        await FileSystem.writeAsStringAsync(htmlPath, htmlContent, { encoding: FileSystem.EncodingType.UTF8 });
        paths.pdf = htmlPath;
      }

      // Write EPUB content
      if (selectedFormats.has('epub')) {
        const epubContent = generateEPUBContent(meta, blocks, selectedStyle);
        const epubPath = FileSystem.documentDirectory + `${safeName}.epub`;
        await FileSystem.writeAsStringAsync(epubPath, epubContent, { encoding: FileSystem.EncodingType.UTF8 });
        paths.epub = epubPath;
      }

      // Write RTF/DOCX content
      if (selectedFormats.has('docx')) {
        const rtfContent = generateRTF(meta, blocks, selectedStyle);
        const docxPath = FileSystem.documentDirectory + `${safeName}.rtf`;
        await FileSystem.writeAsStringAsync(docxPath, rtfContent, { encoding: FileSystem.EncodingType.UTF8 });
        paths.docx = docxPath;
      }

      setGeneratedPaths(paths);
      incrementExportCount();
      setStatus('done');
    } catch (err) {
      console.error(err);
      setStatus('error');
    }
  };

  const shareFile = async (path: string, mimeType: string) => {
    try {
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(path, { mimeType, dialogTitle: `Share ${title}` });
      } else {
        Alert.alert('Sharing unavailable', 'File saved to: ' + path);
      }
    } catch (err) {
      Alert.alert('Error', 'Could not share the file. Try again.');
    }
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => router.back()} style={styles.navBack}>
          <Text style={styles.navBackText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.navTitle}>Export</Text>
        <View style={{ width: 60 }} />
      </View>

      <View style={styles.steps}>
        {['Manuscript', 'Style', 'Export'].map((s, i) => (
          <View key={i} style={styles.stepItem}>
            <View style={[styles.stepDot, i < 2 && styles.stepDone, i === 2 && styles.stepDotActive]}>
              <Text style={[styles.stepNum, styles.stepNumActive]}>{i < 2 ? '✓' : i + 1}</Text>
            </View>
            <Text style={[styles.stepLabel, i === 2 && styles.stepLabelActive]}>{s}</Text>
          </View>
        ))}
      </View>

      {status === 'idle' && (
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
          {/* Free tier warning */}
          {!isPro && (
            <View style={styles.freeBanner}>
              <Text style={styles.freeBannerText}>
                Free tier: {exportCount}/3 exports used.{' '}
                <Text style={styles.upgradeLink} onPress={() => router.push('/paywall')}>Upgrade to Pro →</Text>
              </Text>
            </View>
          )}

          {/* Format selection */}
          <Text style={styles.sectionLabel}>Export Formats</Text>
          {[
            { key: 'pdf' as ExportFormat, icon: '📄', label: 'PDF', desc: 'Best for Gumroad, direct sales & print', pro: false },
            { key: 'epub' as ExportFormat, icon: '📱', label: 'EPUB', desc: 'Kindle, Apple Books, Kobo', pro: true },
            { key: 'docx' as ExportFormat, icon: '📝', label: 'DOCX/RTF', desc: 'Word, Google Docs, editing', pro: true },
          ].map(f => {
            const isLocked = f.pro && !isPro;
            const isChecked = selectedFormats.has(f.key);
            return (
              <TouchableOpacity
                key={f.key}
                style={[styles.formatRow, isChecked && styles.formatRowSelected, isLocked && { opacity: 0.6 }]}
                onPress={() => isLocked ? router.push('/paywall') : toggleFormat(f.key)}
                activeOpacity={0.8}
              >
                <View style={[styles.checkbox, isChecked && styles.checkboxSelected]}>
                  {isChecked && <Text style={{ color: 'white', fontSize: 10 }}>✓</Text>}
                </View>
                <Text style={styles.formatIcon}>{f.icon}</Text>
                <View style={{ flex: 1 }}>
                  <Text style={styles.formatLabel}>{f.label} {isLocked && <Text style={styles.proTag}>PRO</Text>}</Text>
                  <Text style={styles.formatDesc}>{f.desc}</Text>
                </View>
              </TouchableOpacity>
            );
          })}

          {/* Preview */}
          <Text style={styles.sectionLabel}>Preview</Text>
          <TouchableOpacity style={styles.previewToggle} onPress={() => setShowPreview(!showPreview)}>
            <Text style={styles.previewToggleText}>{showPreview ? 'Hide Preview ↑' : 'Show Formatted Preview ↓'}</Text>
          </TouchableOpacity>

          {showPreview && (
            <View style={styles.previewContainer}>
              <WebView
                source={{ html: htmlContent }}
                style={styles.webview}
                scrollEnabled
                showsVerticalScrollIndicator={false}
              />
            </View>
          )}

          <View style={{ height: 20 }} />
        </ScrollView>
      )}

      {status === 'generating' && (
        <View style={styles.generating}>
          <ActivityIndicator size="large" color={theme.colors.gold} />
          <Text style={styles.genTitle}>Formatting Your Book...</Text>
          <Text style={styles.genStep}>{STEPS[stepIndex]}</Text>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: `${progress * 100}%` }]} />
          </View>
        </View>
      )}

      {status === 'done' && (
        <ScrollView style={styles.scroll} contentContainerStyle={styles.content}>
          <View style={styles.successBanner}>
            <Text style={styles.successIcon}>✓</Text>
            <View>
              <Text style={styles.successTitle}>Your Ebook Is Ready!</Text>
              <Text style={styles.successSub}>All formats generated. Tap to share or save.</Text>
            </View>
          </View>

          {generatedPaths.pdf && (
            <TouchableOpacity style={styles.downloadCard} onPress={() => shareFile(generatedPaths.pdf, 'text/html')} activeOpacity={0.85}>
              <Text style={styles.dlIcon}>📄</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.dlLabel}>PDF (HTML)</Text>
                <Text style={styles.dlDesc}>Open in browser → Print → Save as PDF</Text>
              </View>
              <Text style={styles.dlArrow}>↗</Text>
            </TouchableOpacity>
          )}

          {generatedPaths.epub && (
            <TouchableOpacity style={styles.downloadCard} onPress={() => shareFile(generatedPaths.epub, 'application/epub+zip')} activeOpacity={0.85}>
              <Text style={styles.dlIcon}>📱</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.dlLabel}>EPUB</Text>
                <Text style={styles.dlDesc}>Send to Kindle, Apple Books, or Kobo</Text>
              </View>
              <Text style={styles.dlArrow}>↗</Text>
            </TouchableOpacity>
          )}

          {generatedPaths.docx && (
            <TouchableOpacity style={styles.downloadCard} onPress={() => shareFile(generatedPaths.docx, 'application/msword')} activeOpacity={0.85}>
              <Text style={styles.dlIcon}>📝</Text>
              <View style={{ flex: 1 }}>
                <Text style={styles.dlLabel}>RTF (Word compatible)</Text>
                <Text style={styles.dlDesc}>Open in Word, Google Docs, or Pages</Text>
              </View>
              <Text style={styles.dlArrow}>↗</Text>
            </TouchableOpacity>
          )}

          <TouchableOpacity style={styles.btnSecondary} onPress={() => { setStatus('idle'); setGeneratedPaths({}); }} activeOpacity={0.8}>
            <Text style={styles.btnSecondaryText}>← Format Another Book</Text>
          </TouchableOpacity>
        </ScrollView>
      )}

      {status === 'error' && (
        <View style={styles.generating}>
          <Text style={{ fontSize: 40, marginBottom: 16 }}>⚠️</Text>
          <Text style={styles.genTitle}>Something went wrong</Text>
          <Text style={styles.genStep}>Please try again. Make sure you have content in your manuscript.</Text>
          <TouchableOpacity style={[styles.btnPrimary, { marginTop: 24 }]} onPress={() => setStatus('idle')}>
            <Text style={styles.btnPrimaryText}>Try Again</Text>
          </TouchableOpacity>
        </View>
      )}

      {/* Bottom CTA */}
      {status === 'idle' && (
        <View style={styles.bottomBar}>
          <TouchableOpacity
            style={[styles.btnGold, !canExport && { opacity: 0.5 }]}
            onPress={startExport}
            activeOpacity={0.85}
          >
            <Text style={styles.btnGoldText}>✦  Generate & Download All Formats</Text>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

function sleep(ms: number) { return new Promise(r => setTimeout(r, ms)); }

function generateRTF(meta: any, blocks: any[], style: any): string {
  const s = STYLES[style as any] || STYLES.classic;
  let rtf = `{\\rtf1\\ansi\\deff0\n{\\fonttbl{\\f0 Times New Roman;}{\\f1 Arial;}}\n{\\colortbl;\\red26\\green18\\blue8;\\red139\\green58\\blue42;}\n\\paperw12240\\paperh15840\\margl1440\\margr1440\\margt1440\\margb1440\n\\f0\\fs24\\par\n{\\pard\\qc\\b\\fs40 ${escRtf(meta.title)}\\b0\\par}\n{\\pard\\qc\\i\\fs22 by ${escRtf(meta.author)}\\i0\\par}\n\\pard\\par\n`;
  for (const b of blocks) {
    if (b.type === 'h1') rtf += `{\\pard\\sb360\\sa120\\b\\fs32\\cf2 ${escRtf(b.text)}\\b0\\par}\n`;
    else if (b.type === 'h2') rtf += `{\\pard\\sb240\\sa80\\b\\fs26\\cf2 ${escRtf(b.text)}\\b0\\par}\n`;
    else if (b.type === 'h3') rtf += `{\\pard\\sb160\\sa60\\b\\fs24\\cf1 ${escRtf(b.text)}\\b0\\par}\n`;
    else rtf += `{\\pard\\fi720\\sb0\\sa120\\fs22\\cf1 ${escRtf(b.text)}\\par}\n`;
  }
  rtf += '}';
  return rtf;
}

function escRtf(s: string): string {
  return s.replace(/\\/g, '\\\\').replace(/\{/g, '\\{').replace(/\}/g, '\\}');
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.cream },
  scroll: { flex: 1 },
  content: { padding: theme.spacing.md },
  navbar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.md, paddingVertical: 12,
    borderBottomWidth: 1, borderBottomColor: theme.colors.goldLight,
    backgroundColor: theme.colors.parchment,
  },
  navBack: { padding: 4 },
  navBackText: { color: theme.colors.rust, fontSize: 14, fontWeight: '500' },
  navTitle: { fontFamily: 'Georgia', fontSize: 17, fontWeight: '700', color: theme.colors.ink },
  steps: {
    flexDirection: 'row', justifyContent: 'center', gap: 32, padding: 12,
    backgroundColor: theme.colors.parchment,
    borderBottomWidth: 1, borderBottomColor: theme.colors.goldLight,
  },
  stepItem: { alignItems: 'center', gap: 4 },
  stepDot: {
    width: 24, height: 24, borderRadius: 12,
    borderWidth: 1.5, borderColor: theme.colors.goldLight,
    backgroundColor: theme.colors.cream,
    alignItems: 'center', justifyContent: 'center',
  },
  stepDone: { backgroundColor: theme.colors.sage, borderColor: theme.colors.sage },
  stepDotActive: { backgroundColor: theme.colors.gold, borderColor: theme.colors.gold },
  stepNum: { fontSize: 11, fontWeight: '600', color: theme.colors.gray500 },
  stepNumActive: { color: 'white' },
  stepLabel: { fontSize: 10, fontWeight: '500', color: theme.colors.gray500, letterSpacing: 0.5 },
  stepLabelActive: { color: theme.colors.ink },

  freeBanner: {
    backgroundColor: 'rgba(201,168,76,0.1)',
    borderWidth: 1, borderColor: 'rgba(201,168,76,0.3)',
    borderRadius: theme.radius.sm, padding: 12, marginBottom: 16,
  },
  freeBannerText: { fontSize: 13, color: '#6a5a1a' },
  upgradeLink: { color: theme.colors.rust, fontWeight: '600' },

  sectionLabel: {
    fontSize: 11, fontWeight: '600', letterSpacing: 1.2,
    textTransform: 'uppercase', color: '#6a5a3a',
    marginBottom: 10, marginTop: 16,
  },
  formatRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    padding: 14, borderWidth: 1.5, borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.sm, marginBottom: 8, backgroundColor: theme.colors.cream,
  },
  formatRowSelected: { borderColor: theme.colors.gold, backgroundColor: 'rgba(201,168,76,0.05)' },
  checkbox: {
    width: 20, height: 20, borderRadius: 4,
    borderWidth: 1.5, borderColor: theme.colors.goldLight,
    alignItems: 'center', justifyContent: 'center',
  },
  checkboxSelected: { backgroundColor: theme.colors.gold, borderColor: theme.colors.gold },
  formatIcon: { fontSize: 22 },
  formatLabel: { fontSize: 14, fontWeight: '600', color: theme.colors.ink, marginBottom: 2 },
  formatDesc: { fontSize: 12, color: theme.colors.gray500 },
  proTag: { fontSize: 9, color: theme.colors.gold, fontWeight: '700', letterSpacing: 1 },

  previewToggle: {
    padding: 12, borderWidth: 1, borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.sm, alignItems: 'center',
    backgroundColor: theme.colors.parchment,
  },
  previewToggleText: { fontSize: 13, color: theme.colors.rust, fontWeight: '500' },
  previewContainer: { height: 400, borderRadius: theme.radius.sm, overflow: 'hidden', marginTop: 8, borderWidth: 1, borderColor: theme.colors.goldLight },
  webview: { flex: 1 },

  generating: {
    flex: 1, alignItems: 'center', justifyContent: 'center', padding: 32,
  },
  genTitle: { fontFamily: 'Georgia', fontSize: 22, fontWeight: '700', color: theme.colors.ink, marginTop: 20, marginBottom: 8 },
  genStep: { fontSize: 14, color: theme.colors.gray500, textAlign: 'center', marginBottom: 24 },
  progressBar: { width: '80%', height: 4, backgroundColor: theme.colors.goldLight, borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: theme.colors.gold, borderRadius: 2 },

  successBanner: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    backgroundColor: 'rgba(74,94,74,0.08)', borderWidth: 1,
    borderColor: 'rgba(74,94,74,0.25)', borderRadius: theme.radius.md, padding: 16, marginBottom: 20,
  },
  successIcon: {
    width: 40, height: 40, borderRadius: 20, backgroundColor: theme.colors.sage,
    textAlign: 'center', textAlignVertical: 'center', color: 'white', fontSize: 18, overflow: 'hidden',
    lineHeight: 40,
  },
  successTitle: { fontFamily: 'Georgia', fontSize: 16, fontWeight: '700', color: theme.colors.sage },
  successSub: { fontSize: 13, color: '#5a7a5a' },

  downloadCard: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    padding: 16, borderWidth: 1.5, borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.md, marginBottom: 10,
    backgroundColor: theme.colors.parchment, ...theme.shadow.sm,
  },
  dlIcon: { fontSize: 28 },
  dlLabel: { fontSize: 14, fontWeight: '600', color: theme.colors.ink, marginBottom: 2 },
  dlDesc: { fontSize: 12, color: theme.colors.gray500 },
  dlArrow: { fontSize: 20, color: theme.colors.gold, fontWeight: '300' },

  bottomBar: {
    padding: theme.spacing.md, backgroundColor: theme.colors.parchment,
    borderTopWidth: 1, borderTopColor: theme.colors.goldLight,
  },
  btnGold: {
    backgroundColor: theme.colors.gold, paddingVertical: 16,
    borderRadius: theme.radius.sm, alignItems: 'center',
  },
  btnGoldText: { color: theme.colors.ink, fontSize: 14, fontWeight: '700', letterSpacing: 1 },
  btnPrimary: {
    backgroundColor: theme.colors.ink, paddingVertical: 14,
    borderRadius: theme.radius.sm, alignItems: 'center', paddingHorizontal: 32,
  },
  btnPrimaryText: { color: theme.colors.gold, fontSize: 13, fontWeight: '600', letterSpacing: 1, textTransform: 'uppercase' },
  btnSecondary: {
    marginTop: 16, padding: 14, borderWidth: 1.5, borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.sm, alignItems: 'center',
  },
  btnSecondaryText: { fontSize: 13, color: theme.colors.ink, fontWeight: '500' },
});
