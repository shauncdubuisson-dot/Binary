// app/manuscript.tsx
import React, { useState } from 'react';
import {
  View, Text, StyleSheet, TextInput, TouchableOpacity,
  ScrollView, KeyboardAvoidingView, Platform, Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { theme } from '../lib/theme';
import { useStore } from '../lib/store';
import { wordCount } from '../lib/formatter';

export default function ManuscriptScreen() {
  const router = useRouter();
  const {
    title, author, subtitle, blurb, manuscript,
    setTitle, setAuthor, setSubtitle, setBlurb, setManuscript,
    loadSample,
  } = useStore();

  const words = wordCount(manuscript);
  const chars = manuscript.length;

  const handleNext = () => {
    if (!title.trim()) { Alert.alert('Missing Title', 'Please enter your book title before continuing.'); return; }
    if (manuscript.trim().length < 50) { Alert.alert('No Content', 'Please paste your manuscript content before continuing.'); return; }
    router.push('/style');
  };

  return (
    <SafeAreaView style={styles.safe}>
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>

        {/* Nav bar */}
        <View style={styles.navbar}>
          <TouchableOpacity onPress={() => router.back()} style={styles.navBack}>
            <Text style={styles.navBackText}>← Back</Text>
          </TouchableOpacity>
          <Text style={styles.navTitle}>Manuscript</Text>
          <TouchableOpacity onPress={loadSample}>
            <Text style={styles.navAction}>Sample</Text>
          </TouchableOpacity>
        </View>

        {/* Step indicator */}
        <View style={styles.steps}>
          {['Manuscript', 'Style', 'Export'].map((s, i) => (
            <View key={i} style={styles.stepItem}>
              <View style={[styles.stepDot, i === 0 && styles.stepDotActive]}>
                <Text style={[styles.stepNum, i === 0 && styles.stepNumActive]}>{i + 1}</Text>
              </View>
              <Text style={[styles.stepLabel, i === 0 && styles.stepLabelActive]}>{s}</Text>
            </View>
          ))}
        </View>

        <ScrollView style={styles.scroll} contentContainerStyle={styles.content} keyboardShouldPersistTaps="handled">

          {/* Tip */}
          <View style={styles.tip}>
            <Text style={styles.tipText}>💡 Use # Chapter Title and ## Section Title to structure your book. Blank lines create paragraph breaks.</Text>
          </View>

          {/* Title & Author */}
          <View style={styles.row}>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Book Title *</Text>
              <TextInput
                style={styles.input}
                value={title}
                onChangeText={setTitle}
                placeholder="The AI Advantage"
                placeholderTextColor={theme.colors.gray300}
              />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={styles.label}>Author Name *</Text>
              <TextInput
                style={styles.input}
                value={author}
                onChangeText={setAuthor}
                placeholder="Your Name"
                placeholderTextColor={theme.colors.gray300}
              />
            </View>
          </View>

          <View style={styles.field}>
            <Text style={styles.label}>Subtitle <Text style={styles.optional}>(optional)</Text></Text>
            <TextInput
              style={styles.input}
              value={subtitle}
              onChangeText={setSubtitle}
              placeholder="e.g. How to Build a Business With AI"
              placeholderTextColor={theme.colors.gray300}
            />
          </View>

          {/* Manuscript */}
          <View style={styles.field}>
            <View style={styles.labelRow}>
              <Text style={styles.label}>Manuscript *</Text>
              <Text style={styles.counter}>{chars.toLocaleString()} chars · {words.toLocaleString()} words</Text>
            </View>
            <TextInput
              style={[styles.input, styles.textArea]}
              value={manuscript}
              onChangeText={setManuscript}
              placeholder={`# Introduction\nPaste your AI-generated book content here...\n\n# Chapter 1: Getting Started\nYour chapter content. Each blank line creates a paragraph break.\n\n## Section 1.1\nSub-sections work too...`}
              placeholderTextColor={theme.colors.gray300}
              multiline
              textAlignVertical="top"
              autoCorrect={false}
              autoCapitalize="sentences"
            />
          </View>

          {/* Back cover blurb */}
          <View style={styles.field}>
            <Text style={styles.label}>Back Cover Description <Text style={styles.optional}>(optional)</Text></Text>
            <TextInput
              style={[styles.input, { height: 90 }]}
              value={blurb}
              onChangeText={setBlurb}
              placeholder="A 2–3 sentence description for your product listing..."
              placeholderTextColor={theme.colors.gray300}
              multiline
              textAlignVertical="top"
            />
          </View>

          <View style={{ height: 20 }} />
        </ScrollView>

        {/* Bottom CTA */}
        <View style={styles.bottomBar}>
          <TouchableOpacity style={styles.btnPrimary} onPress={handleNext} activeOpacity={0.85}>
            <Text style={styles.btnPrimaryText}>Continue to Style →</Text>
          </TouchableOpacity>
        </View>

      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.cream },
  scroll: { flex: 1 },
  content: { padding: theme.spacing.md },

  navbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.goldLight,
    backgroundColor: theme.colors.parchment,
  },
  navBack: { padding: 4 },
  navBackText: { color: theme.colors.rust, fontSize: 14, fontWeight: '500' },
  navTitle: { fontFamily: 'Georgia', fontSize: 17, fontWeight: '700', color: theme.colors.ink },
  navAction: { color: theme.colors.gold, fontSize: 14, fontWeight: '500' },

  steps: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 32,
    padding: 12,
    backgroundColor: theme.colors.parchment,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.goldLight,
  },
  stepItem: { alignItems: 'center', gap: 4 },
  stepDot: {
    width: 24, height: 24, borderRadius: 12,
    borderWidth: 1.5, borderColor: theme.colors.goldLight,
    backgroundColor: theme.colors.cream,
    alignItems: 'center', justifyContent: 'center',
  },
  stepDotActive: { backgroundColor: theme.colors.gold, borderColor: theme.colors.gold },
  stepNum: { fontSize: 11, fontWeight: '600', color: theme.colors.gray500 },
  stepNumActive: { color: 'white' },
  stepLabel: { fontSize: 10, fontWeight: '500', color: theme.colors.gray500, letterSpacing: 0.5 },
  stepLabelActive: { color: theme.colors.ink },

  tip: {
    backgroundColor: 'rgba(201,168,76,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(201,168,76,0.25)',
    borderRadius: theme.radius.sm,
    padding: 12,
    marginBottom: theme.spacing.md,
  },
  tipText: { fontSize: 12, color: '#6a5a1a', lineHeight: 18 },

  row: { flexDirection: 'row', gap: 12, marginBottom: theme.spacing.md },
  field: { marginBottom: theme.spacing.md },
  label: {
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 1,
    textTransform: 'uppercase',
    color: '#6a5a3a',
    marginBottom: 6,
  },
  labelRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: 6 },
  optional: { textTransform: 'none', letterSpacing: 0, fontWeight: '300', fontSize: 11, color: theme.colors.gray500 },
  counter: { fontSize: 11, color: theme.colors.gray500 },

  input: {
    backgroundColor: theme.colors.cream,
    borderWidth: 1,
    borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.sm,
    paddingHorizontal: 12,
    paddingVertical: 10,
    fontSize: 14,
    color: theme.colors.ink,
    fontFamily: 'System',
  },
  textArea: { height: 280, paddingTop: 12, fontFamily: 'System', lineHeight: 22 },

  bottomBar: {
    padding: theme.spacing.md,
    backgroundColor: theme.colors.parchment,
    borderTopWidth: 1,
    borderTopColor: theme.colors.goldLight,
  },
  btnPrimary: {
    backgroundColor: theme.colors.ink,
    paddingVertical: 16,
    borderRadius: theme.radius.sm,
    alignItems: 'center',
  },
  btnPrimaryText: {
    color: theme.colors.gold,
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
});
