// app/style.tsx
import React from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { theme } from '../lib/theme';
import { useStore } from '../lib/store';
import { STYLES, StyleKey } from '../lib/formatter';

const STYLE_PREVIEWS: Record<StyleKey, { bg: string; text: string; accent: string }> = {
  classic:  { bg: '#1a1208', text: '#f5f0e8', accent: '#8b3a2a' },
  modern:   { bg: '#0d2a4a', text: '#f0f4f8', accent: '#4a9aca' },
  bold:     { bg: '#2d0a0a', text: '#f5eeee', accent: '#c04040' },
  minimal:  { bg: '#2a2a2a', text: '#f5f5f5', accent: '#888888' },
  academic: { bg: '#0a2a1a', text: '#f0f5f0', accent: '#4aaa7a' },
  luxury:   { bg: '#1a1208', text: '#f5f0e8', accent: '#c9a84c' },
};

const STYLE_KEYS = Object.keys(STYLES) as StyleKey[];

const FONT_SIZES = [
  { label: '11pt — Compact', value: 11 },
  { label: '12pt — Standard', value: 12 },
  { label: '13pt — Comfortable', value: 13 },
  { label: '14pt — Large', value: 14 },
];

const PAGE_SIZES = [
  { label: 'Letter — US Standard', value: 'letter' as const },
  { label: 'A4 — International', value: 'a4' as const },
  { label: '5×8" — KDP Digest', value: 'digest' as const },
];

export default function StyleScreen() {
  const router = useRouter();
  const {
    selectedStyle, fontSize, pageSize,
    includeToc, includeCopyright, includePageNumbers, includeCover,
    setStyle, setFontSize, setPageSize,
    setIncludeToc, setIncludeCopyright, setIncludePageNumbers, setIncludeCover,
  } = useStore();

  return (
    <SafeAreaView style={styles.safe}>

      {/* Nav */}
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => router.back()} style={styles.navBack}>
          <Text style={styles.navBackText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.navTitle}>Style</Text>
        <View style={{ width: 60 }} />
      </View>

      {/* Steps */}
      <View style={styles.steps}>
        {['Manuscript', 'Style', 'Export'].map((s, i) => (
          <View key={i} style={styles.stepItem}>
            <View style={[styles.stepDot, i === 0 && styles.stepDone, i === 1 && styles.stepDotActive]}>
              <Text style={[styles.stepNum, (i === 0 || i === 1) && styles.stepNumActive]}>{i === 0 ? '✓' : i + 1}</Text>
            </View>
            <Text style={[styles.stepLabel, i === 1 && styles.stepLabelActive]}>{s}</Text>
          </View>
        ))}
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Style grid */}
        <Text style={styles.sectionLabel}>Publishing Style</Text>
        <View style={styles.styleGrid}>
          {STYLE_KEYS.map((key) => {
            const s = STYLES[key];
            const p = STYLE_PREVIEWS[key];
            const isSelected = selectedStyle === key;
            return (
              <TouchableOpacity
                key={key}
                style={[styles.styleCard, isSelected && styles.styleCardSelected]}
                onPress={() => setStyle(key)}
                activeOpacity={0.8}
              >
                <View style={[styles.stylePreview, { backgroundColor: p.bg }]}>
                  <Text style={[styles.previewText, { color: p.text }]}>Aa</Text>
                  <View style={[styles.previewLine, { backgroundColor: p.accent }]} />
                  <View style={[styles.previewLine, { backgroundColor: p.text, opacity: 0.4, width: '60%' }]} />
                </View>
                <Text style={[styles.styleName, isSelected && styles.styleNameSelected]}>{s.name}</Text>
                <Text style={styles.styleDesc}>{s.description}</Text>
                {isSelected && <View style={styles.checkMark}><Text style={{ color: 'white', fontSize: 10 }}>✓</Text></View>}
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Font size */}
        <Text style={styles.sectionLabel}>Font Size</Text>
        <View style={styles.optionRow}>
          {FONT_SIZES.map(f => (
            <TouchableOpacity
              key={f.value}
              style={[styles.optionPill, fontSize === f.value && styles.optionPillSelected]}
              onPress={() => setFontSize(f.value)}
            >
              <Text style={[styles.optionPillText, fontSize === f.value && styles.optionPillTextSelected]}>
                {f.value}pt
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        {/* Page size */}
        <Text style={styles.sectionLabel}>Page Size</Text>
        {PAGE_SIZES.map(p => (
          <TouchableOpacity
            key={p.value}
            style={[styles.radioRow, pageSize === p.value && styles.radioRowSelected]}
            onPress={() => setPageSize(p.value)}
          >
            <View style={[styles.radio, pageSize === p.value && styles.radioSelected]} />
            <Text style={styles.radioLabel}>{p.label}</Text>
          </TouchableOpacity>
        ))}

        {/* Front matter toggles */}
        <Text style={styles.sectionLabel}>Include in Book</Text>
        {[
          { label: 'Table of Contents', value: includeToc, setter: setIncludeToc },
          { label: 'Copyright Page', value: includeCopyright, setter: setIncludeCopyright },
          { label: 'Page Numbers', value: includePageNumbers, setter: setIncludePageNumbers },
          { label: 'Cover Page', value: includeCover, setter: setIncludeCover },
        ].map(item => (
          <View key={item.label} style={styles.toggleRow}>
            <Text style={styles.toggleLabel}>{item.label}</Text>
            <Switch
              value={item.value}
              onValueChange={item.setter}
              trackColor={{ false: theme.colors.gray300, true: theme.colors.gold }}
              thumbColor="white"
            />
          </View>
        ))}

        <View style={{ height: 20 }} />
      </ScrollView>

      {/* Bottom CTA */}
      <View style={styles.bottomBar}>
        <TouchableOpacity style={styles.btnPrimary} onPress={() => router.push('/export')} activeOpacity={0.85}>
          <Text style={styles.btnPrimaryText}>Continue to Export →</Text>
        </TouchableOpacity>
      </View>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.cream },
  scroll: { flex: 1 },
  content: { padding: theme.spacing.md },

  navbar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.md,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.goldLight,
    backgroundColor: theme.colors.parchment,
  },
  navBack: { padding: 4 },
  navBackText: { color: theme.colors.rust, fontSize: 14, fontWeight: '500' },
  navTitle: { fontFamily: 'Georgia', fontSize: 17, fontWeight: '700', color: theme.colors.ink },

  steps: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 32,
    padding: 12,
    backgroundColor: theme.colors.parchment,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.goldLight,
  },
  stepItem: { alignItems: 'center', gap: 4 },
  stepDot: {
    width: 24, height: 24, borderRadius: 12,
    borderWidth: 1.5, borderColor: theme.colors.goldLight,
    backgroundColor: theme.colors.cream,
    alignItems: 'center', justifyContent: 'center',
  },
  stepDone: { backgroundColor: theme.colors.sage, borderColor: theme.colors.sage },
  stepDotActive: { backgroundColor: theme.colors.gold, borderColor: theme.colors.gold },
  stepNum: { fontSize: 11, fontWeight: '600', color: theme.colors.gray500 },
  stepNumActive: { color: 'white' },
  stepLabel: { fontSize: 10, fontWeight: '500', color: theme.colors.gray500, letterSpacing: 0.5 },
  stepLabelActive: { color: theme.colors.ink },

  sectionLabel: {
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    color: '#6a5a3a',
    marginBottom: 12,
    marginTop: theme.spacing.md,
  },

  styleGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 4,
  },
  styleCard: {
    width: '30.5%',
    borderWidth: 1.5,
    borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.md,
    overflow: 'hidden',
    backgroundColor: theme.colors.cream,
    position: 'relative',
  },
  styleCardSelected: {
    borderColor: theme.colors.gold,
    ...theme.shadow.sm,
  },
  stylePreview: {
    height: 64,
    padding: 10,
    justifyContent: 'center',
    gap: 4,
  },
  previewText: { fontFamily: 'Georgia', fontSize: 16, fontWeight: '700' },
  previewLine: { height: 2, width: '80%', borderRadius: 1, marginTop: 2 },
  styleName: { fontSize: 11, fontWeight: '600', color: theme.colors.ink, padding: 8, paddingBottom: 2 },
  styleNameSelected: { color: theme.colors.gold },
  styleDesc: { fontSize: 10, color: theme.colors.gray500, paddingHorizontal: 8, paddingBottom: 10, lineHeight: 14 },
  checkMark: {
    position: 'absolute',
    top: 6, right: 6,
    width: 18, height: 18,
    borderRadius: 9,
    backgroundColor: theme.colors.gold,
    alignItems: 'center', justifyContent: 'center',
  },

  optionRow: { flexDirection: 'row', gap: 8, marginBottom: 4 },
  optionPill: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: theme.radius.full,
    borderWidth: 1.5,
    borderColor: theme.colors.goldLight,
    backgroundColor: theme.colors.cream,
  },
  optionPillSelected: { backgroundColor: theme.colors.gold, borderColor: theme.colors.gold },
  optionPillText: { fontSize: 12, fontWeight: '500', color: theme.colors.gray700 },
  optionPillTextSelected: { color: 'white', fontWeight: '700' },

  radioRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.sm,
    marginBottom: 8,
    backgroundColor: theme.colors.cream,
  },
  radioRowSelected: { borderColor: theme.colors.gold, backgroundColor: 'rgba(201,168,76,0.06)' },
  radio: {
    width: 18, height: 18, borderRadius: 9,
    borderWidth: 1.5, borderColor: theme.colors.goldLight,
  },
  radioSelected: { borderColor: theme.colors.gold, borderWidth: 5 },
  radioLabel: { fontSize: 13, color: theme.colors.ink },

  toggleRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 10,
    borderBottomWidth: 1,
    borderBottomColor: theme.colors.goldLight,
  },
  toggleLabel: { fontSize: 14, color: theme.colors.ink, fontWeight: '400' },

  bottomBar: {
    padding: theme.spacing.md,
    backgroundColor: theme.colors.parchment,
    borderTopWidth: 1,
    borderTopColor: theme.colors.goldLight,
  },
  btnPrimary: {
    backgroundColor: theme.colors.ink,
    paddingVertical: 16,
    borderRadius: theme.radius.sm,
    alignItems: 'center',
  },
  btnPrimaryText: {
    color: theme.colors.gold,
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 1.2,
    textTransform: 'uppercase',
  },
});
