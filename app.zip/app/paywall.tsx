// app/paywall.tsx
import React from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity, ScrollView, Linking,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { theme } from '../lib/theme';
import { useStore } from '../lib/store';

const PRO_FEATURES = [
  '✦  Unlimited exports — no monthly cap',
  '✦  PDF, EPUB & DOCX — all three formats',
  '✦  No watermark on any export',
  '✦  All 6 publishing styles unlocked',
  '✦  Custom copyright page text',
  '✦  Priority processing',
];

const PUBLISHER_FEATURES = [
  '✦  Everything in Pro',
  '✦  Batch format up to 10 books at once',
  '✦  White-label — remove Bindery branding',
  '✦  API access for automations',
  '✦  Upload custom style templates',
  '✦  Priority email support',
];

export default function PaywallScreen() {
  const router = useRouter();
  const { setIsPro } = useStore();

  // In production: replace with real Stripe/RevenueCat purchase flow
  const handleUpgrade = (plan: 'pro' | 'publisher') => {
    // TODO: integrate Stripe or RevenueCat here
    // For now simulate purchase for demo
    setIsPro(true);
    router.back();
  };

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.navbar}>
        <TouchableOpacity onPress={() => router.back()}>
          <Text style={styles.navClose}>✕</Text>
        </TouchableOpacity>
        <Text style={styles.navTitle}>Upgrade Bindery</Text>
        <View style={{ width: 32 }} />
      </View>

      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.heroEyebrow}>UNLOCK THE FULL BINDERY</Text>
          <Text style={styles.heroTitle}>Publish Without Limits</Text>
          <Text style={styles.heroSub}>Format as many books as you want. Export every format. No watermarks. Cancel any time.</Text>
        </View>

        {/* Ornament */}
        <View style={styles.ornament}>
          <View style={styles.ornamentLine} />
          <View style={styles.ornamentDiamond} />
          <View style={styles.ornamentLine} />
        </View>

        {/* Pro card */}
        <View style={styles.planCard}>
          <View style={styles.planBadge}><Text style={styles.planBadgeText}>MOST POPULAR</Text></View>
          <Text style={styles.planName}>Pro</Text>
          <View style={styles.priceRow}>
            <Text style={styles.priceAmount}>$9</Text>
            <Text style={styles.pricePeriod}>/month</Text>
          </View>
          <Text style={styles.priceAnnual}>or $79/year — save 26%</Text>

          {PRO_FEATURES.map((f, i) => (
            <Text key={i} style={styles.featureItem}>{f}</Text>
          ))}

          <TouchableOpacity style={styles.btnGold} onPress={() => handleUpgrade('pro')} activeOpacity={0.85}>
            <Text style={styles.btnGoldText}>Start Pro — $9/month</Text>
          </TouchableOpacity>
          <Text style={styles.cancelNote}>Cancel any time. No questions asked.</Text>
        </View>

        {/* Publisher card */}
        <View style={[styles.planCard, styles.planCardDark]}>
          <Text style={[styles.planName, { color: theme.colors.goldLight }]}>Publisher</Text>
          <View style={styles.priceRow}>
            <Text style={[styles.priceAmount, { color: theme.colors.gold }]}>$29</Text>
            <Text style={[styles.pricePeriod, { color: theme.colors.goldLight }]}>/month</Text>
          </View>

          {PUBLISHER_FEATURES.map((f, i) => (
            <Text key={i} style={[styles.featureItem, { color: theme.colors.goldLight }]}>{f}</Text>
          ))}

          <TouchableOpacity style={styles.btnOutlineGold} onPress={() => handleUpgrade('publisher')} activeOpacity={0.85}>
            <Text style={styles.btnOutlineGoldText}>Go Publisher — $29/month</Text>
          </TouchableOpacity>
        </View>

        {/* Free note */}
        <TouchableOpacity style={styles.continueLink} onPress={() => router.back()}>
          <Text style={styles.continueLinkText}>Continue with Free (3 exports/month) →</Text>
        </TouchableOpacity>

        {/* Trust signals */}
        <View style={styles.trust}>
          <Text style={styles.trustItem}>🔒 Secure payment via Stripe</Text>
          <Text style={styles.trustItem}>↩ Cancel any time</Text>
          <Text style={styles.trustItem}>📱 Works on iOS & Android</Text>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.cream },
  scroll: { flex: 1 },
  content: { padding: theme.spacing.md },
  navbar: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: theme.spacing.md, paddingVertical: 14,
    borderBottomWidth: 1, borderBottomColor: theme.colors.goldLight,
    backgroundColor: theme.colors.parchment,
  },
  navClose: { fontSize: 18, color: theme.colors.gray500, padding: 4 },
  navTitle: { fontFamily: 'Georgia', fontSize: 17, fontWeight: '700', color: theme.colors.ink },

  hero: { alignItems: 'center', paddingVertical: theme.spacing.xl },
  heroEyebrow: { fontSize: 10, fontWeight: '700', letterSpacing: 2, color: theme.colors.gold, marginBottom: 8 },
  heroTitle: { fontFamily: 'Georgia', fontSize: 30, fontWeight: '900', color: theme.colors.ink, textAlign: 'center', marginBottom: 12 },
  heroSub: { fontSize: 14, color: '#5a4e3a', textAlign: 'center', lineHeight: 22, fontWeight: '300', maxWidth: 300 },

  ornament: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: theme.spacing.xl },
  ornamentLine: { flex: 1, height: 1, backgroundColor: theme.colors.goldLight },
  ornamentDiamond: { width: 8, height: 8, backgroundColor: theme.colors.gold, transform: [{ rotate: '45deg' }] },

  planCard: {
    backgroundColor: theme.colors.parchment,
    borderWidth: 1.5, borderColor: theme.colors.gold,
    borderRadius: theme.radius.lg, padding: theme.spacing.lg,
    marginBottom: theme.spacing.md, position: 'relative',
    ...theme.shadow.md,
  },
  planCardDark: { backgroundColor: theme.colors.ink, borderColor: theme.colors.gold },
  planBadge: {
    position: 'absolute', top: -12, alignSelf: 'center',
    backgroundColor: theme.colors.gold, paddingHorizontal: 12, paddingVertical: 4,
    borderRadius: theme.radius.full,
  },
  planBadgeText: { fontSize: 9, fontWeight: '700', letterSpacing: 1.5, color: theme.colors.ink },
  planName: { fontFamily: 'Georgia', fontSize: 24, fontWeight: '900', color: theme.colors.ink, marginBottom: 8, marginTop: 8 },
  priceRow: { flexDirection: 'row', alignItems: 'baseline', gap: 4, marginBottom: 4 },
  priceAmount: { fontFamily: 'Georgia', fontSize: 42, fontWeight: '900', color: theme.colors.ink },
  pricePeriod: { fontSize: 16, color: theme.colors.gray500 },
  priceAnnual: { fontSize: 12, color: theme.colors.sage, marginBottom: theme.spacing.md },
  featureItem: { fontSize: 13, color: '#2a1a08', paddingVertical: 5, borderBottomWidth: 1, borderBottomColor: theme.colors.goldLight },

  btnGold: {
    backgroundColor: theme.colors.gold, paddingVertical: 16,
    borderRadius: theme.radius.sm, alignItems: 'center', marginTop: theme.spacing.lg,
  },
  btnGoldText: { color: theme.colors.ink, fontSize: 15, fontWeight: '700', letterSpacing: 0.5 },
  cancelNote: { fontSize: 11, color: theme.colors.gray500, textAlign: 'center', marginTop: 8 },

  btnOutlineGold: {
    borderWidth: 1.5, borderColor: theme.colors.gold,
    paddingVertical: 16, borderRadius: theme.radius.sm,
    alignItems: 'center', marginTop: theme.spacing.lg,
  },
  btnOutlineGoldText: { color: theme.colors.gold, fontSize: 15, fontWeight: '600' },

  continueLink: { alignItems: 'center', paddingVertical: theme.spacing.md },
  continueLinkText: { fontSize: 13, color: theme.colors.gray500, textDecorationLine: 'underline' },

  trust: { flexDirection: 'row', justifyContent: 'space-around', flexWrap: 'wrap', gap: 8, paddingVertical: 16 },
  trustItem: { fontSize: 12, color: theme.colors.gray500 },
});
