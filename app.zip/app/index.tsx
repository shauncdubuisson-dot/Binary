// app/index.tsx  (Home Screen)
import React from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, Image, StatusBar, Dimensions,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { theme } from '../lib/theme';
import { useStore } from '../lib/store';

const { width } = Dimensions.get('window');

const FEATURES = [
  { icon: '📖', title: 'Auto Chapter Detection', desc: 'Paste AI text — chapters detected instantly' },
  { icon: '🎨', title: '6 Publishing Styles', desc: 'Classic, Modern, Bold, Minimal, Academic, Luxury' },
  { icon: '⚡', title: 'Three Formats', desc: 'PDF, EPUB, and DOCX in one tap' },
  { icon: '🛒', title: 'KDP-Ready', desc: 'Optimized for Amazon Kindle Direct Publishing' },
  { icon: '🔒', title: '100% Private', desc: 'Nothing leaves your device' },
  { icon: '✦', title: 'Auto TOC', desc: 'Table of contents generated automatically' },
];

export default function HomeScreen() {
  const router = useRouter();
  const { loadSample, setScreen } = useStore();

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar barStyle="dark-content" backgroundColor={theme.colors.cream} />
      <ScrollView style={styles.scroll} contentContainerStyle={styles.content} showsVerticalScrollIndicator={false}>

        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.logoMark}>Bindery</Text>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>BETA · FREE</Text>
          </View>
        </View>

        {/* Hero */}
        <View style={styles.hero}>
          <Text style={styles.eyebrow}>PROFESSIONAL PUBLISHING IN MINUTES</Text>
          <Text style={styles.heroTitle}>Turn AI Text Into a{'\n'}<Text style={styles.heroAccent}>Publication-Ready</Text>{'\n'}Ebook</Text>
          <Text style={styles.heroSub}>Paste your AI manuscript. Choose a style. Download a professionally formatted PDF, EPUB & DOCX — ready for Amazon KDP or Gumroad.</Text>

          <TouchableOpacity style={styles.ctaPrimary} onPress={() => router.push('/manuscript')} activeOpacity={0.85}>
            <Text style={styles.ctaPrimaryText}>✦  Format My Book</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.ctaSecondary} onPress={() => { loadSample(); router.push('/manuscript'); }} activeOpacity={0.8}>
            <Text style={styles.ctaSecondaryText}>Try with a sample book →</Text>
          </TouchableOpacity>
        </View>

        {/* Ornament */}
        <View style={styles.ornament}>
          <View style={styles.ornamentLine} />
          <View style={styles.ornamentDiamond} />
          <View style={styles.ornamentLine} />
        </View>

        {/* Features */}
        <Text style={styles.sectionTitle}>Everything You Need to Publish</Text>
        <View style={styles.featuresGrid}>
          {FEATURES.map((f, i) => (
            <View key={i} style={styles.featureCard}>
              <Text style={styles.featureIcon}>{f.icon}</Text>
              <Text style={styles.featureTitle}>{f.title}</Text>
              <Text style={styles.featureDesc}>{f.desc}</Text>
            </View>
          ))}
        </View>

        {/* Pricing teaser */}
        <View style={styles.pricingCard}>
          <Text style={styles.pricingEyebrow}>SIMPLE PRICING</Text>
          <View style={styles.pricingRow}>
            <View style={styles.priceTier}>
              <Text style={styles.priceName}>Free</Text>
              <Text style={styles.priceAmount}>$0</Text>
              <Text style={styles.priceDesc}>3 exports/mo{'\n'}PDF only{'\n'}Watermarked</Text>
            </View>
            <View style={[styles.priceTier, styles.priceFeatured]}>
              <Text style={styles.priceBadge}>POPULAR</Text>
              <Text style={[styles.priceName, { color: theme.colors.gold }]}>Pro</Text>
              <Text style={[styles.priceAmount, { color: theme.colors.gold }]}>$9<Text style={{ fontSize: 14 }}>/mo</Text></Text>
              <Text style={[styles.priceDesc, { color: theme.colors.goldLight }]}>Unlimited exports{'\n'}PDF+EPUB+DOCX{'\n'}No watermark</Text>
            </View>
            <View style={styles.priceTier}>
              <Text style={styles.priceName}>Publisher</Text>
              <Text style={styles.priceAmount}>$29<Text style={{ fontSize: 14 }}>/mo</Text></Text>
              <Text style={styles.priceDesc}>Batch 10 books{'\n'}White-label{'\n'}API access</Text>
            </View>
          </View>
        </View>

        <View style={{ height: 40 }} />
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: theme.colors.cream },
  scroll: { flex: 1 },
  content: { padding: theme.spacing.md },

  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: theme.spacing.sm,
    marginBottom: theme.spacing.lg,
  },
  logoMark: {
    fontFamily: 'Georgia',
    fontSize: 28,
    fontWeight: '900',
    color: theme.colors.ink,
    letterSpacing: -0.5,
  },
  badge: {
    borderWidth: 1,
    borderColor: theme.colors.sage,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: theme.radius.sm,
  },
  badgeText: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 1.5,
    color: theme.colors.sage,
  },

  hero: { marginBottom: theme.spacing.xl },
  eyebrow: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 2,
    color: theme.colors.gold,
    marginBottom: theme.spacing.sm,
  },
  heroTitle: {
    fontFamily: 'Georgia',
    fontSize: 36,
    fontWeight: '900',
    color: theme.colors.ink,
    lineHeight: 42,
    marginBottom: theme.spacing.md,
    letterSpacing: -0.5,
  },
  heroAccent: { color: theme.colors.rust, fontStyle: 'italic' },
  heroSub: {
    fontSize: 15,
    fontWeight: '300',
    color: '#5a4e3a',
    lineHeight: 24,
    marginBottom: theme.spacing.xl,
  },

  ctaPrimary: {
    backgroundColor: theme.colors.ink,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: theme.radius.sm,
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
    ...theme.shadow.md,
  },
  ctaPrimaryText: {
    color: theme.colors.gold,
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  ctaSecondary: {
    alignItems: 'center',
    paddingVertical: theme.spacing.sm,
  },
  ctaSecondaryText: {
    color: theme.colors.rust,
    fontSize: 14,
    fontWeight: '500',
  },

  ornament: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: theme.spacing.xl,
    gap: 12,
  },
  ornamentLine: { flex: 1, height: 1, backgroundColor: theme.colors.goldLight },
  ornamentDiamond: {
    width: 8, height: 8,
    backgroundColor: theme.colors.gold,
    transform: [{ rotate: '45deg' }],
  },

  sectionTitle: {
    fontFamily: 'Georgia',
    fontSize: 22,
    fontWeight: '700',
    color: theme.colors.ink,
    textAlign: 'center',
    marginBottom: theme.spacing.lg,
  },

  featuresGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: theme.spacing.xl,
  },
  featureCard: {
    width: (width - theme.spacing.md * 2 - 12) / 2,
    backgroundColor: theme.colors.parchment,
    borderWidth: 1,
    borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.md,
    padding: theme.spacing.md,
    ...theme.shadow.sm,
  },
  featureIcon: { fontSize: 24, marginBottom: 8 },
  featureTitle: {
    fontFamily: 'Georgia',
    fontSize: 13,
    fontWeight: '700',
    color: theme.colors.ink,
    marginBottom: 4,
  },
  featureDesc: { fontSize: 12, color: '#6a5a3a', fontWeight: '300', lineHeight: 17 },

  pricingCard: {
    backgroundColor: theme.colors.parchment,
    borderWidth: 1,
    borderColor: theme.colors.goldLight,
    borderRadius: theme.radius.md,
    padding: theme.spacing.lg,
    ...theme.shadow.sm,
  },
  pricingEyebrow: {
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 2,
    color: theme.colors.gold,
    textAlign: 'center',
    marginBottom: theme.spacing.md,
  },
  pricingRow: {
    flexDirection: 'row',
    gap: 8,
  },
  priceTier: {
    flex: 1,
    alignItems: 'center',
    padding: 12,
    borderRadius: theme.radius.sm,
    borderWidth: 1,
    borderColor: theme.colors.goldLight,
  },
  priceFeatured: {
    backgroundColor: theme.colors.ink,
    borderColor: theme.colors.gold,
  },
  priceBadge: {
    fontSize: 8,
    fontWeight: '700',
    letterSpacing: 1,
    color: theme.colors.gold,
    marginBottom: 4,
  },
  priceName: {
    fontFamily: 'Georgia',
    fontSize: 13,
    fontWeight: '700',
    color: theme.colors.ink,
  },
  priceAmount: {
    fontFamily: 'Georgia',
    fontSize: 22,
    fontWeight: '900',
    color: theme.colors.ink,
    marginVertical: 4,
  },
  priceDesc: {
    fontSize: 10,
    color: theme.colors.gray500,
    textAlign: 'center',
    lineHeight: 16,
  },
});
